// =====================================================
//  TRIM & GLOW — booking.js
//  JS Feature #2: AJAX availability check
//  JS Feature #3: Multi-step booking wizard
// =====================================================

// ---- Booking state ----
const booking = {
  serviceId:   null,
  serviceName: null,
  price:       null,
  stylistId:   null,
  stylistName: null,
  date:        null,
  time:        null,
  step:        1,
};

// ---- Update the sidebar summary ----
function updateSummary() {
  document.getElementById('sum_service').textContent  = booking.serviceName || '—';
  document.getElementById('sum_stylist').textContent  = booking.stylistName || '—';
  document.getElementById('sum_date').textContent     = booking.date        || '—';
  document.getElementById('sum_time').textContent     = booking.time        || '—';
  document.getElementById('sum_price').textContent    = booking.price ? `K${booking.price}` : '—';
}

// ---- Step navigation ----
function goToStep(step) {
  // Hide all panels
  document.querySelectorAll('.booking-panel').forEach(p => p.classList.remove('active'));
  // Show target panel
  const panel = document.getElementById(`step${step}`);
  if (panel) panel.classList.add('active');

  // Update tab indicators
  document.querySelectorAll('.booking-step-tab').forEach(tab => {
    const tabStep = parseInt(tab.dataset.step);
    tab.classList.remove('active', 'done');
    if (tabStep === step) tab.classList.add('active');
    if (tabStep < step)  tab.classList.add('done');
  });

  booking.step = step;
  window.scrollTo({ top: 200, behavior: 'smooth' });
}

// ---- Step 1: Service selection ----
function initServiceSelection() {
  document.querySelectorAll('.service-option').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.service-option').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      booking.serviceId   = card.dataset.serviceId;
      booking.serviceName = card.querySelector('h4').textContent;
      booking.price       = card.dataset.price;
      updateSummary();
    });
  });

  document.getElementById('nextToStep2')?.addEventListener('click', () => {
    if (!booking.serviceId) {
      showToast('Please select a service first.', 'error');
      return;
    }
    goToStep(2);
  });
}

// ---- Step 2: Stylist selection ----
function initStylistSelection() {
  document.querySelectorAll('.stylist-option').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.stylist-option').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      booking.stylistId   = card.dataset.stylistId;
      booking.stylistName = card.querySelector('h4').textContent;
      updateSummary();
    });
  });

  document.getElementById('nextToStep3')?.addEventListener('click', () => {
    if (!booking.stylistId) {
      showToast('Please choose a stylist.', 'error');
      return;
    }
    goToStep(3);
  });

  document.getElementById('backToStep1')?.addEventListener('click', () => goToStep(1));
}

// ---- Step 3: Date & Time with AJAX availability check ----
function initDateTimeSelection() {
  const dateInput = document.getElementById('bookingDate');
  const timeSlots = document.querySelectorAll('.time-slot:not(.unavailable)');

  // Minimum date = today
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;

    // JS Feature #2: AJAX check when date changes
    dateInput.addEventListener('change', () => {
      booking.date = dateInput.value;
      booking.time = null;
      document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
      updateSummary();
      checkDateAvailability(dateInput.value);
    });
  }

  timeSlots.forEach(slot => {
    slot.addEventListener('click', () => {
      timeSlots.forEach(s => s.classList.remove('selected'));
      slot.classList.add('selected');
      booking.time = slot.textContent.trim();
      updateSummary();
    });
  });

  document.getElementById('nextToStep4')?.addEventListener('click', () => {
    if (!booking.date) { showToast('Please select a date.', 'error'); return; }
    if (!booking.time) { showToast('Please pick a time slot.', 'error'); return; }
    goToStep(4);
  });

  document.getElementById('backToStep2')?.addEventListener('click', () => goToStep(2));
}

// ---- AJAX availability check ----
async function checkDateAvailability(date) {
  const msgEl = document.getElementById('availabilityMsg');
  if (!msgEl) return;

  // Show "checking" state
  msgEl.className = 'availability-msg show checking';
  msgEl.innerHTML = '⏳ Checking availability...';

  try {
    // Real AJAX call — your PHP backend handles this endpoint
    const response = await fetch(`api/check_availability.php?date=${date}&stylist=${booking.stylistId}`);

    if (!response.ok) throw new Error('Server error');
    const data = await response.json();

    if (data.available) {
      msgEl.className = 'availability-msg show available';
      msgEl.innerHTML = `✅ ${data.slots_left} time slots available on this date.`;
      // Mark unavailable slots from server response
      if (data.booked_times) {
        document.querySelectorAll('.time-slot').forEach(slot => {
          if (data.booked_times.includes(slot.textContent.trim())) {
            slot.classList.add('unavailable');
          } else {
            slot.classList.remove('unavailable');
          }
        });
      }
    } else {
      msgEl.className = 'availability-msg show busy';
      msgEl.innerHTML = '⚠️ This date is fully booked. Please choose another date.';
    }
  } catch (err) {
    // Fallback if backend not yet connected — simulate response
    console.warn('Backend not connected, using demo mode:', err.message);
    simulateAvailabilityCheck(date, msgEl);
  }
}

// Demo mode (runs when PHP backend isn't connected yet)
function simulateAvailabilityCheck(date, msgEl) {
  const d = new Date(date);
  const isSunday = d.getDay() === 0;

  if (isSunday) {
    msgEl.className = 'availability-msg show busy';
    msgEl.innerHTML = '⚠️ We are closed on Sundays. Please choose another date.';
    document.querySelectorAll('.time-slot').forEach(s => s.classList.add('unavailable'));
  } else {
    const slotsLeft = Math.floor(Math.random() * 5) + 3;
    msgEl.className = 'availability-msg show available';
    msgEl.innerHTML = `✅ ${slotsLeft} time slots available on this date.`;

    // Randomly mark some slots as unavailable for demo
    const slots = document.querySelectorAll('.time-slot');
    slots.forEach(s => s.classList.remove('unavailable', 'selected'));
    slots.forEach((s, i) => {
      if (Math.random() < 0.25) s.classList.add('unavailable');
    });
  }
}

// ---- Step 4: Confirm & submit ----
function initConfirmation() {
  document.getElementById('backToStep3')?.addEventListener('click', () => goToStep(3));

  document.getElementById('confirmBookingBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('confirmBookingBtn');
    btn.textContent = 'Submitting...';
    btn.disabled = true;

    // Gather all booking data
    const payload = {
      service_id:   booking.serviceId,
      stylist_id:   booking.stylistId,
      date:         booking.date,
      time:         booking.time,
      customer_name: document.getElementById('cust_name')?.value,
      customer_phone: document.getElementById('cust_phone')?.value,
      notes:        document.getElementById('cust_notes')?.value,
    };

    try {
      // AJAX submit to PHP backend
      const response = await fetch('api/create_booking.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error('Booking failed');
      const result = await response.json();

      showToast(`Booking confirmed! Reference: #${result.booking_ref || 'TG' + Date.now()}`, 'success');
      setTimeout(() => window.location.href = 'dashboard.html', 2000);
    } catch (err) {
      // Demo mode
      showToast('Booking confirmed! (Demo mode) Reference: #TG' + Math.floor(Math.random()*10000), 'success');
      setTimeout(() => window.location.href = 'dashboard.html', 2000);
    }
  });
}

// ---- Pre-select service from URL params (e.g. booking.html?service=2) ----
function preselectFromURL() {
  const params = new URLSearchParams(window.location.search);
  const serviceId = params.get('service');
  if (serviceId) {
    const card = document.querySelector(`.service-option[data-service-id="${serviceId}"]`);
    if (card) card.click();
  }
}

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => {
  initServiceSelection();
  initStylistSelection();
  initDateTimeSelection();
  initConfirmation();
  preselectFromURL();
  goToStep(1);
});