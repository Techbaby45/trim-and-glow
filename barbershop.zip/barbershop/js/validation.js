// =====================================================
//  TRIM & GLOW — validation.js
//  JavaScript Feature #1: Real-time form validation
//  Used on: register.html, login.html
// =====================================================

// ---------- Helpers ----------
function setError(inputId, message) {
  const input = document.getElementById(inputId);
  const msg   = document.getElementById(inputId + '_msg');
  if (!input) return;
  input.classList.remove('valid');
  input.classList.add('error');
  if (msg) { msg.textContent = message; msg.className = 'field-msg show err'; }
}

function setValid(inputId, message = '✓ Looks good') {
  const input = document.getElementById(inputId);
  const msg   = document.getElementById(inputId + '_msg');
  if (!input) return;
  input.classList.remove('error');
  input.classList.add('valid');
  if (msg) { msg.textContent = message; msg.className = 'field-msg show ok'; }
}

function clearField(inputId) {
  const input = document.getElementById(inputId);
  const msg   = document.getElementById(inputId + '_msg');
  if (!input) return;
  input.classList.remove('error', 'valid');
  if (msg) { msg.className = 'field-msg'; }
}

// ---------- Validators ----------
function validateName(value) {
  if (!value.trim())         return 'Full name is required.';
  if (value.trim().length < 3) return 'Name must be at least 3 characters.';
  if (!/^[a-zA-Z\s]+$/.test(value)) return 'Name can only contain letters.';
  return null;
}

function validateEmail(value) {
  if (!value.trim())   return 'Email address is required.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Enter a valid email (e.g. you@example.com)';
  return null;
}

function validatePhone(value) {
  const cleaned = value.replace(/\s/g, '');
  if (!cleaned)       return 'Phone number is required.';
  if (!/^(\+26[01]|0)[79]\d{8}$/.test(cleaned)) return 'Enter a valid Zambian number (e.g. 0977123456)';
  return null;
}

function validatePassword(value) {
  if (!value)           return 'Password is required.';
  if (value.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(value)) return 'Include at least one capital letter.';
  if (!/[0-9]/.test(value)) return 'Include at least one number.';
  return null;
}

function validateConfirmPassword(value, password) {
  if (!value)           return 'Please confirm your password.';
  if (value !== password) return 'Passwords do not match.';
  return null;
}

// ---------- Password strength meter ----------
function updateStrengthMeter(password) {
  const bar   = document.getElementById('strengthBar');
  const label = document.getElementById('strengthLabel');
  if (!bar || !label) return;

  let score = 0;
  if (password.length >= 8)        score++;
  if (/[A-Z]/.test(password))      score++;
  if (/[a-z]/.test(password))      score++;
  if (/[0-9]/.test(password))      score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  const levels = [
    { pct: '0%',   color: '#DDD', text: '' },
    { pct: '20%',  color: '#E74C3C', text: 'Very weak' },
    { pct: '40%',  color: '#E67E22', text: 'Weak' },
    { pct: '60%',  color: '#F1C40F', text: 'Fair' },
    { pct: '80%',  color: '#27AE60', text: 'Strong' },
    { pct: '100%', color: '#1A8A4A', text: 'Very strong' },
  ];
  const level = levels[score] || levels[0];
  bar.style.width = level.pct;
  bar.style.background = level.color;
  label.textContent = level.text;
  label.style.color = level.color;
}

// ---------- Attach to registration form ----------
function initRegisterForm() {
  const form = document.getElementById('registerForm');
  if (!form) return;

  const fields = {
    full_name:        () => validateName(document.getElementById('full_name')?.value),
    email:            () => validateEmail(document.getElementById('email')?.value),
    phone:            () => validatePhone(document.getElementById('phone')?.value),
    password:         () => validatePassword(document.getElementById('password')?.value),
    confirm_password: () => validateConfirmPassword(
      document.getElementById('confirm_password')?.value,
      document.getElementById('password')?.value
    ),
  };

  // Live validation on blur
  Object.keys(fields).forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input',  () => clearField(id));
    el.addEventListener('blur',   () => {
      const err = fields[id]();
      err ? setError(id, err) : setValid(id);
    });
  });

  // Password strength meter on keyup
  const pwField = document.getElementById('password');
  if (pwField) {
    pwField.addEventListener('input', () => updateStrengthMeter(pwField.value));
  }

  // On submit — validate all fields
  form.addEventListener('submit', e => {
    e.preventDefault();
    let allValid = true;
    Object.keys(fields).forEach(id => {
      const err = fields[id]();
      if (err) { setError(id, err); allValid = false; }
      else { setValid(id); }
    });

    if (allValid) {
      // Hand off to PHP backend
      showToast('Creating your account...', 'info');
      // Uncomment below when backend is ready:
      // form.submit();
      // Demo: show success
      setTimeout(() => {
        showToast('Account created! Redirecting...', 'success');
        setTimeout(() => window.location.href = 'login.html', 1500);
      }, 800);
    } else {
      showToast('Please fix the highlighted fields.', 'error');
    }
  });
}

// ---------- Attach to login form ----------
function initLoginForm() {
  const form = document.getElementById('loginForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const email    = document.getElementById('login_email');
    const password = document.getElementById('login_password');
    let valid = true;

    const emailErr = validateEmail(email?.value);
    if (emailErr) { setError('login_email', emailErr); valid = false; }
    else setValid('login_email');

    if (!password?.value) { setError('login_password', 'Password is required.'); valid = false; }
    else setValid('login_password');

    if (valid) {
      showToast('Signing you in...', 'info');
      // Set login flag (replace with PHP session check when backend is ready)
      localStorage.setItem('tg_logged_in', '1');
      setTimeout(() => { window.location.href = 'booking.html'; }, 1000);
      // form.submit(); // Uncomment for backend
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initRegisterForm();
  initLoginForm();
});