// =====================================================
//  TRIM & GLOW — main.js
//  Handles: navbar, scroll effects, toast, XML loader
// =====================================================

// ---------- Navbar hamburger toggle ----------
const hamburger = document.querySelector('.hamburger');
const navLinks  = document.querySelector('.navbar-links');

if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
}

// ---------- Highlight active nav link ----------
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.navbar-links a').forEach(link => {
  if (link.getAttribute('href') === currentPage) link.classList.add('active');
});

// ---------- Scroll-to-top button ----------
const scrollBtn = document.getElementById('scrollTopBtn');
if (scrollBtn) {
  window.addEventListener('scroll', () => {
    scrollBtn.classList.toggle('show', window.scrollY > 300);
  });
  scrollBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

// ---------- Toast notifications ----------
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

function createToastContainer() {
  const div = document.createElement('div');
  div.id = 'toastContainer';
  div.className = 'toast-container';
  document.body.appendChild(div);
  return div;
}

// ---------- Loader overlay ----------
function showLoader()  { const l = document.getElementById('loader'); if (l) l.classList.add('show'); }
function hideLoader()  { const l = document.getElementById('loader'); if (l) l.classList.remove('show'); }

// ---------- Animate counters (Stats bar) ----------
function animateCounter(el, target) {
  let current = 0;
  const step = Math.ceil(target / 60);
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current.toLocaleString() + (el.dataset.suffix || '');
    if (current >= target) clearInterval(timer);
  }, 25);
}

// Run counters when they enter viewport
const counterEls = document.querySelectorAll('[data-counter]');
if (counterEls.length) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        animateCounter(el, parseInt(el.dataset.counter));
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counterEls.forEach(el => observer.observe(el));
}

// ---------- JavaScript Feature #3: Load services from XML ----------
// This demonstrates XML integration as required by the brief
async function loadServicesFromXML() {
  const container = document.getElementById('xmlServicesContainer');
  if (!container) return;

  try {
    const response = await fetch('xml/services.xml');
    if (!response.ok) throw new Error('Could not load services');
    const xmlText = await response.text();
    const parser  = new DOMParser();
    const xml     = parser.parseFromString(xmlText, 'application/xml');

    const services = xml.querySelectorAll('service');
    container.innerHTML = '';

    services.forEach(svc => {
      const name     = svc.querySelector('name')?.textContent     || '';
      const category = svc.querySelector('category')?.textContent || '';
      const price    = svc.querySelector('price')?.textContent    || '';
      const duration = svc.querySelector('duration')?.textContent || '';
      const desc     = svc.querySelector('description')?.textContent || '';
      const icon     = svc.querySelector('icon')?.textContent     || '✂';
      const id       = svc.getAttribute('id')                    || '';

      container.innerHTML += `
        <div class="service-card" data-service-id="${id}">
          <div class="service-card-img">${icon}</div>
          <div class="service-card-body">
            <span class="service-card-tag">${category}</span>
            <h3>${name}</h3>
            <p>${desc}</p>
            <div class="service-card-footer">
              <span class="service-price">K${price}</span>
              <span class="service-duration">⏱ ${duration} min</span>
            </div>
            <a href="booking.html?service=${id}" class="btn btn-outline" style="margin-top:1rem;width:100%;text-align:center;">Book Now</a>
          </div>
        </div>
      `;
    });
  } catch (err) {
    container.innerHTML = `<p style="color:var(--warm-gray)">Could not load services. Please try again.</p>`;
    console.warn('XML load error:', err.message);
  }
}

document.addEventListener('DOMContentLoaded', loadServicesFromXML);